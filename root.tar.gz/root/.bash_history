history
history -w
rm -f /root/.bash_history
journalctl --rotate
journalctl --vacuum-time=1s
apt clean
sync
poweroff
clear
hostname
hostnamectl set-hostname TPServer
hostname
cat /etc/os-release
cat /etc/apt/source.list
cat /etc/apt/sources.list
cp /etc/apt/sources.list /root/sources.list.bak
apt update
clear
ping -c 3 1.1.1.1
getent hosts deb.debian.org
cat -n /etc/apt/sources.list
nano /etc/apt/sources.list
cat /etc/apt/sources.list
vi /etc/apt/sources.list
apt update 
clear
apt upgrade
dpkg --audit
clear
hostnamectl --static
df -h / /var /boot
apt-mark showhold
ls -la /etc/apt/sources.list.d/
apt update
apt full-upgrade
cp /etc/apt/sources.list /root/sources.list.bullseye.bak
nano /etc/apt/sources.list}
nano /etc/apt/sources.list
apt install nano
nano /etc/apt/sources.list
apt update
apt upgrade --without-new-pkgs
apt full-upgrade
reboot
clear
pwd
ls -l 
clear
apt install -y curl
curl -sS https://starship.rs/install.sh | sh -s -- -y
mkdir -p ~/.config
echo 'eval "$(starship init bash)"' >> ~/.bashrc
exec bash
exit
clear
tar -tzf /root/Material_Adicional_TPVMCA.tar.gz
cd /root
tar -xzf Material_Adicional_TPVMCA.tar.gz
ls -la /root/Material_Adicional_TPVMCA
clear
cat /root/Material_Adicional_TPVMCA/clave_publica.pub
cat /root/Material_Adicional_TPVMCA/clave_publica.pub >> /root/.ssh/authorized_keys
cat /root/.ssh/authorized_keys
chmod 600 /root/Material_Adicional_TPVMCA/clave_privada.txt
clear
ssh -i /root/Material_Adicional_TPVMCA/clave_privada.txt root@localhost
clear
exit
clear
rm -r /root/.ssh
clear
ls -la /root
clear
ssh-keygen
clear
ssh-copy-id root@localhost
ssh root@localhost
ip -br a
exit
clear
apt install -y apache2
clear
apt install -y php libapache2-mod-php
php -v
clear
cat /root/Material_Adicional_TPVMCA/index.php
clear
apt install -y php-mysql
systemctl restart apache2
apt install -y mariadb-server
systemctl status mariadb 
clear
grep -inE 'create database|create user|grant|use ' /root/Material_Adicional_TPVMCA/db.sql
clear
mariadb < /root/Material_Adicional_TPVMCA/db.sql
mariadb -u lcars -pNCC1701D ingenieria -e "SHOW TABLES;" 
cp /root/Material_Adicional_TPVMCA/index.php /root/Material_Adicional_TPVMCA/logo.png
rm var/www/html/index.html
rm /var/www/html/index.html
ls -l /var/www/html
cp /root/Material_Adicional_TPVMCA/index.php /root/Material_Adicional_TPVMCA/logo.png /var/www/html/
ls -l /var/www/html
clear
ls -l /var/www/html
file /var/www/html/logo.png
clear
ls -l /var/www/hyml
ls -l /var/www/html
file /var/www/html/logo.png
clear
ls -l /root/Material_Adicional_TPVMCA/
file /root/Material_Adicional_TPVMCA/logo.png
clear
cd /root
tar -xzf Material_Adicional_TPVMCA.tar.gz Material_Adicional_TPVMCA/logo.png
file /root/Material_Adicional_TPVMCA/logo.png
cp /root/Material_Adicional_TPVMCA/logo.png /var/www/html/
clear
tpoff
