#!/bin/bash
# backup_full.sh - Backup comprimido de un directorio
# Uso: backup_full.sh <origen> <destino>

mostrar_ayuda() {
    echo "Uso: $0 <origen> <destino>"
    echo ""
    echo "Genera un backup comprimido (.tar.gz) del directorio <origen>"
    echo "y lo guarda en <destino> como <nombre>_bkp_AAAAMMDD.tar.gz"
    echo ""
    echo "Ejemplos:"
    echo "  $0 /var/log /backup_dir   -> log_bkp_20240302.tar.gz"
    echo "  $0 /www_dir /backup_dir   -> www_dir_bkp_20240302.tar.gz"
    echo ""
    echo "Opciones:"
    echo "  -help   Muestra esta ayuda"
}

if [ "$1" = "-help" ]; then
    mostrar_ayuda
    exit 0
fi

if [ $# -ne 2 ]; then
    echo "Error: se necesitan 2 argumentos (origen y destino)."
    mostrar_ayuda
    exit 1
fi

ORIGEN="$1"
DESTINO="$2"
FECHA=$(date +%Y%m%d)
NOMBRE=$(basename "$ORIGEN")
ARCHIVO="$DESTINO/${NOMBRE}_bkp_${FECHA}.tar.gz"

# --- Validaciones ---
if [ ! -d "$ORIGEN" ]; then
    echo "Error: el origen '$ORIGEN' no existe o no es un directorio."
    exit 1
fi

if [ ! -d "$DESTINO" ]; then
    echo "Error: el destino '$DESTINO' no existe o no es un directorio."
    exit 1
fi

if ! mountpoint -q "$DESTINO"; then
    echo "Error: el destino '$DESTINO' no tiene un sistema de archivos montado."
    exit 1
fi

if [ ! -w "$DESTINO" ]; then
    echo "Error: no hay permiso de escritura en '$DESTINO'."
    exit 1
fi

# --- Backup ---
if tar -czf "$ARCHIVO" "$ORIGEN" 2>/dev/null; then
    echo "Backup OK: $ARCHIVO"
    exit 0
else
    echo "Error: falló la creación del backup de '$ORIGEN'."
    exit 1
fi
